#############################################################
# FILE : final_project.py
# WRITER : Peleg Lampl , peleg.lampl , 209668375
# EXERCISE : intro2cs1 final project 2024
# DESCRIPTION: Spreadsheet Application
#############################################################
import sys
from sheet import Sheet
from gui import Window
from spreadsheet_controller import SpreadsheetController
import tkinter as tk
from tkinter.simpledialog import askinteger, askstring
import argparse


def get_user_input(root):
    """Get the number of rows and columns for the spreadsheet from the user."""
    while True:
        rows = askinteger("Input", "How many rows do you want in your spreadsheet?", parent=root,
                          minvalue=1, maxvalue=100)
        if rows is None:
            # Handle the case where user presses Enter without input or cancels
            root.destroy()
            return None, None
        break  # Exit the loop if rows is not None

    while True:
        columns = askinteger("Input", "How many columns do you want in your spreadsheet?", parent=root,
                             minvalue=1, maxvalue=26)
        if columns is None:
            # Handle the case where user presses Enter without input or cancels
            root.destroy()
            return None, None
        break  # Exit the loop if columns is not None

    return rows, columns


def get_name_to_sheet(root):
    """Get the name of the sheet from the user."""
    name = askstring('Input', "Enter the name of the sheet: ", parent=root)
    return name


def help_program():
    """Show the custom help message for the program."""
    print("Usage: main.py \n Launch the spreadsheet application.  \n Options:")
    print("For using the app, just run without any options. (python main.py)")
    print("Enter the number of rows and columns for the spreadsheet. (Rows: 1-100, Columns: 1-26) and enter "
          "the name of the sheet.")
    print("The application will open with the specified rows and columns.")
    print("You can enter values directly into the cells. For calculate formulas, use the '=' sign at the beginning. \n"
          "Supported functions: MIN, MAX, SUM, AVERAGE, SQRT, MOD. \n For calculate a range of cells, use the ':' sign." 
          "Example: =SUM(A1:A5) \n For calculating a number of cells, you can use the ',' sign. Example: =SUM(1,2,3,4,5)"
          "\n For calculating a formula with a reference to another cell, use the cell label. Example: =A1 + 1 \n "
          "Press 'Enter' to evaluate a cell. \n Use the toolbar for more options, such as saving, clear, or style.")
    print("For loading JSON file to the sheet, use the 'Load JSON' button in the toolbar. You can load JSON file as a "
          "list, list of lists, or a dictionary of lists that every key represent a column (A, B, C..). \n")

    sys.exit()


def controller():
    """Main controller function to set up the spreadsheet application."""
    root = tk.Tk() # Create the main window
    rows, columns = get_user_input(root)  # Get the number of rows and columns from the user
    if rows is None or columns is None:
        return
    name = get_name_to_sheet(root)  # Get the name of the sheet from the user
    root.title(f"Spreadsheet App - {name}")  # Set the title of the window
    # Create a new Sheet instance with the specified rows and columns
    sheet = Sheet(rows, columns)
    # this method sets up the GUI
    view = Window(root, rows, columns, name)
    # Create a new controller instance with the view and sheet
    controller_sheet = SpreadsheetController(view=view, sheet=sheet)
    # Set the controller for the view
    view.set_controller(controller_sheet)
    # Bind events for the controller
    controller_sheet.bind_events()
    # Run the main loop
    root.mainloop()


def main():
    """Main function to parse command-line arguments and run the controller."""
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--help', action='store_true', help='Show custom help message and exit')
    args = parser.parse_args()
    if args.help:
        # Show the custom help message
        help_program()
        sys.exit()
    # Run the controller to start the application
    controller()


if __name__ == "__main__":
    main()
